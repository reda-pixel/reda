import { motion } from "framer-motion";
import { Shield, Scroll, Users, Globe } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const NewsSection = () => {
  const communityStats = [
    {
      name: "Pandoriae",
      members: "12 membres",
      activity: "Actif",
      color: "bg-purple-600",
    },
    {
      name: "Citrus",
      members: "8 membres",
      activity: "Modéré",
      color: "bg-orange-600",
    },
    {
      name: "Utopia",
      members: "15 membres",
      activity: "Très actif",
      color: "bg-green-600",
    },
    {
      name: "Arcanum",
      members: "6 membres",
      activity: "Nouveau",
      color: "bg-blue-600",
    },
  ];

  const loginForm = {
    username: "",
    password: "",
  };

  return (
    <div className="space-y-6">
      {/* Community Groups */}
      <Card className="bg-medieval-panel border-2 border-amber-600 shadow-xl">
        <CardHeader>
          <CardTitle className="text-amber-200 flex items-center">
            <Shield className="h-5 w-5 mr-2 text-amber-400" />
            Communautés
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {communityStats.map((community, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="flex items-center justify-between p-3 bg-gray-800/30 rounded-lg border border-amber-600/30"
            >
              <div className="flex items-center space-x-3">
                <div className={`w-3 h-3 rounded-full ${community.color}`} />
                <div>
                  <p className="text-amber-200 text-sm font-semibold">
                    {community.name}
                  </p>
                  <p className="text-amber-400 text-xs">{community.members}</p>
                </div>
              </div>
              <span className="text-amber-300 text-xs">
                {community.activity}
              </span>
            </motion.div>
          ))}
        </CardContent>
      </Card>

      {/* Login Section */}
      <Card className="bg-medieval-panel border-2 border-amber-600 shadow-xl">
        <CardHeader>
          <CardTitle className="text-amber-200 flex items-center">
            <Users className="h-5 w-5 mr-2 text-amber-400" />
            Connexion
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="block text-amber-300 text-sm mb-2">
              Nom d'utilisateur:
            </label>
            <input
              type="text"
              className="w-full px-3 py-2 bg-gray-800/50 border border-amber-600/50 rounded text-amber-200 text-sm focus:border-amber-500 focus:outline-none"
              placeholder="Entrez votre nom"
            />
          </div>

          <div>
            <label className="block text-amber-300 text-sm mb-2">
              Mot de passe:
            </label>
            <input
              type="password"
              className="w-full px-3 py-2 bg-gray-800/50 border border-amber-600/50 rounded text-amber-200 text-sm focus:border-amber-500 focus:outline-none"
              placeholder="••••••••"
            />
          </div>

          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              id="remember"
              className="rounded border-amber-600"
            />
            <label htmlFor="remember" className="text-amber-300 text-xs">
              Se souvenir de moi
            </label>
          </div>

          <button className="w-full bg-amber-600 hover:bg-amber-700 text-black font-semibold py-2 px-4 rounded border border-amber-500 transition-colors">
            Se connecter
          </button>

          <div className="text-center space-y-1">
            <a href="#" className="text-amber-400 text-xs hover:text-amber-300">
              Mot de passe oublié ?
            </a>
            <br />
            <a href="#" className="text-amber-400 text-xs hover:text-amber-300">
              Créer un compte
            </a>
          </div>
        </CardContent>
      </Card>

      {/* Footer Notice */}
      <Card className="bg-medieval-panel border-2 border-amber-600 shadow-xl">
        <CardContent className="p-4">
          <div className="text-center">
            <Globe className="h-6 w-6 text-amber-400 mx-auto mb-2" />
            <p className="text-amber-300 text-xs leading-relaxed">
              Forum créé avec une grande diversité d'expérience ! Créez votre
              légende et devenez partie intégrante de cette aventure épique. Nos
              règles sont conçues pour assurer une expérience optimale.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Copyright */}
      <div className="bg-amber-600 rounded-lg p-3 text-center">
        <p className="text-black text-xs font-medium">
          Créé avec un grand respect pour l'univers fantastique ! Créez votre
          légende et devenez acteur d'une guilde qui marquera l'histoire ! ©
          2015 Héredes Paradoxa
        </p>
      </div>
    </div>
  );
};

export default NewsSection;
