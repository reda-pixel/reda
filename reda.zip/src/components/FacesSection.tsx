import { motion } from "framer-motion";
import { User, MessageSquare, Calendar, Trophy } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const FacesSection = () => {
  const faceData = {
    title: "faces",
    subtitle: "Where the Magic Begins",
    mainPost: {
      title: "LUX",
      author: "BY LUX & MERRICK",
      description: "LUXURIOUSLY AWAITED",
      lastPost: "LAST POST MAY 24 2023",
    },
    sideImage: {
      description:
        "Faces is a personal choice forum. People choose faces based on who plays them. If someone plays a face that you like, you can see if they'd be willing to play another character with that same face.",
    },
    categories: [
      "AARON TAYLOR",
      "ALEX MERAZ",
      "ANNIE WERSCHING",
      "AUBREY GRAHAM",
      "AUSTEN BUTLER",
      "BRIAN AUSTIN",
      "CHRISTINA HENDRICKS",
      "CODY BROWN",
      "DYLAN SPRAYBERRY",
      "GEMMA WARD",
      "HOLLAND RODEN",
      "NOLAN FUNK",
    ],
    voting: {
      title: "THIS WEEK",
      options: ["MOST TALKATIVE", "MOST FUNNY", "MOST LOVED"],
      stats: [1, 2, 3, 4, 5, 6],
    },
  };

  return (
    <Card className="bg-gray-800/60 border-gray-700 backdrop-blur-sm">
      <CardHeader className="pb-0">
        <CardTitle className="text-2xl font-light text-gray-200 tracking-wide">
          {faceData.title}
        </CardTitle>
        <p className="text-sm text-gray-500">{faceData.subtitle}</p>
      </CardHeader>
      <CardContent className="p-6">
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main content */}
          <div className="lg:col-span-2">
            {/* Featured post */}
            <div className="mb-6">
              <div className="grid md:grid-cols-4 gap-4 items-start">
                <div className="md:col-span-1">
                  <div className="w-full h-24 bg-gray-700 rounded-lg"></div>
                </div>
                <div className="md:col-span-3">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-lg font-medium text-gray-200 bg-gray-700 px-4 py-2 rounded">
                      {faceData.mainPost.title}
                    </h3>
                    <div className="grid grid-cols-2 gap-2">
                      <button className="bg-gray-700 text-gray-300 text-xs px-2 py-1 rounded">
                        S
                      </button>
                      <button className="bg-gray-700 text-gray-300 text-xs px-2 py-1 rounded">
                        S
                      </button>
                      <button className="bg-gray-700 text-gray-300 text-xs px-2 py-1 rounded">
                        +
                      </button>
                      <button className="bg-gray-700 text-gray-300 text-xs px-2 py-1 rounded">
                        S
                      </button>
                      <button className="bg-gray-700 text-gray-300 text-xs px-2 py-1 rounded">
                        S
                      </button>
                      <button className="bg-gray-700 text-gray-300 text-xs px-2 py-1 rounded">
                        S
                      </button>
                    </div>
                  </div>
                  <p className="text-sm text-gray-400 mb-2">
                    {faceData.mainPost.author}
                  </p>
                  <p className="text-xs text-gray-500">
                    {faceData.mainPost.lastPost}
                  </p>
                </div>
              </div>
            </div>

            {/* Large image and description */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="w-full h-48 bg-gray-700 rounded-lg"></div>
              <div>
                <div className="bg-gray-700 text-gray-200 text-center py-2 px-4 rounded-t">
                  FACES
                </div>
                <div className="bg-gray-750 p-4 rounded-b">
                  <p className="text-xs text-gray-400 leading-relaxed">
                    {faceData.sideImage.description}
                  </p>
                  <div className="mt-4">
                    <div className="bg-gray-700 text-gray-300 text-center py-2 rounded text-xs">
                      FACE CLAIMS CURRENTLY NEEDED
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Face categories */}
            <div className="mt-6">
              <div className="bg-gray-700 text-gray-200 text-center py-2 px-4 rounded-t">
                TAKEN FACES
              </div>
              <div className="bg-gray-750 p-4 rounded-b">
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2 text-xs">
                  {faceData.categories.map((face, index) => (
                    <div
                      key={index}
                      className="bg-gray-600 text-gray-300 px-2 py-1 rounded text-center"
                    >
                      {face}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div>
            <div className="bg-gray-700 text-gray-200 text-center py-2 px-4 rounded-t">
              {faceData.voting.title}
            </div>
            <div className="bg-gray-750 p-4 rounded-b space-y-3">
              {faceData.voting.options.map((option, index) => (
                <div key={index} className="text-xs text-gray-400">
                  {option}
                </div>
              ))}
              <div className="grid grid-cols-3 gap-1 mt-4">
                {faceData.voting.stats.map((stat, index) => (
                  <div
                    key={index}
                    className="bg-gray-600 text-gray-300 text-center py-1 text-xs rounded"
                  >
                    {stat}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default FacesSection;
