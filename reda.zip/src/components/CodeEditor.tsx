import { useState } from "react";
import { FileText, Palette, Code } from "lucide-react";

interface CodeEditorProps {
  htmlCode: string;
  setHtmlCode: (code: string) => void;
  cssCode: string;
  setCssCode: (code: string) => void;
  jsCode: string;
  setJsCode: (code: string) => void;
  activeTab: "html" | "css" | "js";
  setActiveTab: (tab: "html" | "css" | "js") => void;
}

const CodeEditor = ({
  htmlCode,
  setHtmlCode,
  cssCode,
  setCssCode,
  jsCode,
  setJsCode,
  activeTab,
  setActiveTab,
}: CodeEditorProps) => {
  const tabs = [
    { id: "html", label: "HTML", icon: FileText, language: "html" },
    { id: "css", label: "CSS", icon: Palette, language: "css" },
    { id: "js", label: "JavaScript", icon: Code, language: "javascript" },
  ];

  const getCurrentCode = () => {
    switch (activeTab) {
      case "html":
        return htmlCode;
      case "css":
        return cssCode;
      case "js":
        return jsCode;
      default:
        return "";
    }
  };

  const setCurrentCode = (code: string) => {
    switch (activeTab) {
      case "html":
        setHtmlCode(code);
        break;
      case "css":
        setCssCode(code);
        break;
      case "js":
        setJsCode(code);
        break;
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Tab") {
      e.preventDefault();
      const target = e.currentTarget;
      const start = target.selectionStart;
      const end = target.selectionEnd;
      const value = target.value;

      target.value = value.substring(0, start) + "  " + value.substring(end);
      target.selectionStart = target.selectionEnd = start + 2;

      setCurrentCode(target.value);
    }
  };

  return (
    <div className="flex flex-col h-full">
      {/* Tabs */}
      <div className="flex bg-gray-800 border-b border-gray-700">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as "html" | "css" | "js")}
              className={`flex items-center space-x-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
                activeTab === tab.id
                  ? "text-blue-400 border-blue-400 bg-gray-700"
                  : "text-gray-400 border-transparent hover:text-gray-300 hover:bg-gray-750"
              }`}
            >
              <Icon className="h-4 w-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Editor */}
      <div className="flex-1 relative">
        <textarea
          value={getCurrentCode()}
          onChange={(e) => setCurrentCode(e.target.value)}
          onKeyDown={handleKeyDown}
          className="w-full h-full p-4 bg-gray-900 text-gray-100 font-mono text-sm leading-relaxed resize-none border-none outline-none"
          placeholder={`Enter your ${activeTab.toUpperCase()} code here...`}
          spellCheck={false}
          style={{
            tabSize: 2,
            lineHeight: "1.5",
          }}
        />

        {/* Line numbers */}
        <div className="absolute left-0 top-0 p-4 pr-2 text-gray-500 font-mono text-sm leading-relaxed pointer-events-none select-none">
          {getCurrentCode()
            .split("\n")
            .map((_, index) => (
              <div key={index} className="text-right w-8">
                {index + 1}
              </div>
            ))}
        </div>

        <style jsx>{`
          textarea {
            padding-left: 3.5rem;
          }
        `}</style>
      </div>

      {/* Status Bar */}
      <div className="bg-gray-800 border-t border-gray-700 px-4 py-2 text-xs text-gray-400 flex justify-between">
        <div className="flex items-center space-x-4">
          <span>
            Language: {tabs.find((t) => t.id === activeTab)?.language}
          </span>
          <span>Lines: {getCurrentCode().split("\n").length}</span>
          <span>Characters: {getCurrentCode().length}</span>
        </div>
        <div>{activeTab.toUpperCase()} Editor</div>
      </div>
    </div>
  );
};

export default CodeEditor;
