import { motion } from "framer-motion";
import { MessageCircle, Users, Eye, Clock } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const ForumSection = () => {
  const forumPosts = [
    {
      title: "ILS SONT ATTENDUES !",
      author: "Silas Howl",
      authorAvatar: "/placeholder.svg",
      lastPost: "Viktor Pembroke",
      content:
        "Depuis 1999 l'univers à été fui, remodelé. Fruits d'un nouveau départ à tête ou anciens pensionaires peuvent convenir le monde encore remails entre dans une âme ou ils prennent des valmes et ce depuis que personne ne pouvait le nommer...",
      stats: {
        members: 11,
        messages: 435,
        views: 1234,
      },
      timestamp: "Il y a 2 heures",
    },
    {
      title: "Lucian Ashgrave",
      author: "Omnis Gaunt",
      authorAvatar: "/placeholder.svg",
      lastPost: "Pendante",
      content:
        "Libre depuis DÉCOUVRIR AU CŒUR - Lucian Ashgrave révèle à été fui, remodelé. Plus de 72 dernières heures.",
      stats: {
        members: 8,
        messages: 156,
        views: 892,
      },
      timestamp: "Il y a 5 heures",
    },
  ];

  const activeMembers = [
    { name: "Silas Howl", avatar: "/placeholder.svg", status: "online" },
    { name: "Viktor Pembroke", avatar: "/placeholder.svg", status: "online" },
    { name: "Lucian Ashgrave", avatar: "/placeholder.svg", status: "away" },
    { name: "Omnis Gaunt", avatar: "/placeholder.svg", status: "offline" },
    { name: "Pendante", avatar: "/placeholder.svg", status: "online" },
  ];

  return (
    <div className="space-y-6">
      {/* Active members section */}
      <Card className="bg-medieval-panel border-2 border-amber-600 shadow-xl">
        <CardHeader>
          <CardTitle className="text-amber-200 flex items-center">
            <Users className="h-5 w-5 mr-2 text-amber-400" />
            ILS SONT ATTENDUES !
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-5 gap-4 mb-4">
            {activeMembers.map((member, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
                className="text-center"
              >
                <div className="relative mb-2">
                  <div className="w-12 h-12 bg-gradient-to-br from-amber-400 to-amber-600 rounded-full flex items-center justify-center text-black font-bold">
                    {member.name.charAt(0)}
                  </div>
                  <div
                    className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-medieval-panel ${
                      member.status === "online"
                        ? "bg-green-500"
                        : member.status === "away"
                          ? "bg-yellow-500"
                          : "bg-gray-500"
                    }`}
                  />
                </div>
                <p className="text-xs text-amber-300 truncate">{member.name}</p>
              </motion.div>
            ))}
          </div>

          <div className="grid grid-cols-3 gap-4 text-center">
            <button className="bg-amber-600 hover:bg-amber-700 text-black font-semibold py-2 px-3 rounded border border-amber-500 transition-colors text-sm">
              Silas Howl
            </button>
            <button className="bg-amber-600 hover:bg-amber-700 text-black font-semibold py-2 px-3 rounded border border-amber-500 transition-colors text-sm">
              Viktor Pembroke
            </button>
            <button className="bg-amber-600 hover:bg-amber-700 text-black font-semibold py-2 px-3 rounded border border-amber-500 transition-colors text-sm">
              Lucian Ashgrave
            </button>
          </div>
          <div className="text-center mt-4">
            <button className="bg-amber-600 hover:bg-amber-700 text-black font-semibold py-2 px-6 rounded border border-amber-500 transition-colors text-sm">
              Omnis Gaunt
            </button>
          </div>
        </CardContent>
      </Card>

      {/* Forum posts */}
      <div className="space-y-4">
        {forumPosts.map((post, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.2 }}
          >
            <Card className="bg-medieval-panel border border-amber-600/50 hover:border-amber-500 transition-colors shadow-lg">
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-amber-400 to-amber-600 rounded-full flex items-center justify-center text-black font-bold flex-shrink-0">
                    {post.author.charAt(0)}
                  </div>

                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-lg font-semibold text-amber-200">
                        {post.title}
                      </h3>
                      <div className="flex items-center space-x-4 text-sm text-amber-400">
                        <span className="flex items-center">
                          <Users className="h-4 w-4 mr-1" />
                          {post.stats.members}
                        </span>
                        <span className="flex items-center">
                          <MessageCircle className="h-4 w-4 mr-1" />
                          {post.stats.messages}
                        </span>
                        <span className="flex items-center">
                          <Eye className="h-4 w-4 mr-1" />
                          {post.stats.views}
                        </span>
                      </div>
                    </div>

                    <p className="text-amber-300 text-sm mb-3 leading-relaxed">
                      {post.content}
                    </p>

                    <div className="flex items-center justify-between text-xs text-amber-400">
                      <span>Par {post.author}</span>
                      <div className="flex items-center space-x-4">
                        <span>Dernier: {post.lastPost}</span>
                        <span className="flex items-center">
                          <Clock className="h-3 w-3 mr-1" />
                          {post.timestamp}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default ForumSection;
