import { motion } from "framer-motion";
import { Users, MessageSquare, TrendingUp, Calendar } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const MembersSection = () => {
  const stats = [
    { label: "Membres", value: "11", icon: Users, color: "text-blue-400" },
    {
      label: "Messages",
      value: "435",
      icon: MessageSquare,
      color: "text-green-400",
    },
  ];

  const recentNews = [
    {
      date: "04.05.2015",
      title: "Ouverture du forum !",
      excerpt: "Bienvenue à tous sur Héredes Paradoxa !",
    },
    {
      date: "02.05.2015",
      title: "Pré-ouverture en bêta",
      excerpt: "Les bêta-testeurs peuvent maintenant accéder au forum.",
    },
    {
      date: "01.04.2015",
      title: "Création du forum",
      excerpt: "Début du développement d'Héredes Paradoxa.",
    },
  ];

  return (
    <div className="space-y-6">
      {/* Statistics */}
      <Card className="bg-medieval-panel border-2 border-amber-600 shadow-xl">
        <CardHeader>
          <CardTitle className="text-amber-200 text-center">
            Statistiques
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4 text-center">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
                className="bg-amber-600 rounded-lg p-4 border border-amber-500"
              >
                <div className="flex flex-col items-center">
                  <stat.icon className="h-6 w-6 text-black mb-2" />
                  <span className="text-2xl font-bold text-black">
                    {stat.value}
                  </span>
                  <span className="text-sm font-medium text-black">
                    {stat.label}
                  </span>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="mt-6 text-center">
            <p className="text-amber-300 text-sm mb-2">Bienvenue à:</p>
            <p className="text-amber-200 font-semibold">Nom d'utilisateur</p>
            <p className="text-amber-400 text-xs mt-2">
              Utilisateurs enregistrés : Aucun
              <br />
              Membres connectés au cours des 72 dernières heures : 3
            </p>
          </div>
        </CardContent>
      </Card>

      {/* News */}
      <Card className="bg-medieval-panel border-2 border-amber-600 shadow-xl">
        <CardHeader>
          <CardTitle className="text-amber-200 flex items-center">
            <Calendar className="h-5 w-5 mr-2 text-amber-400" />
            NOUVEAUTÉS
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {recentNews.map((news, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="border-l-2 border-amber-500 pl-4 py-2"
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-amber-400 text-xs font-mono">
                  {news.date}
                </span>
                <TrendingUp className="h-3 w-3 text-amber-400" />
              </div>
              <h4 className="text-amber-200 text-sm font-semibold mb-1">
                {news.title}
              </h4>
              <p className="text-amber-300 text-xs">{news.excerpt}</p>
            </motion.div>
          ))}
        </CardContent>
      </Card>

      {/* Voting section */}
      <Card className="bg-medieval-panel border-2 border-amber-600 shadow-xl">
        <CardHeader>
          <CardTitle className="text-amber-200 text-center">
            LES VOTES
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center">
          <div className="flex justify-center space-x-2 mb-4">
            {[1, 2, 3, 4, 5].map((rating) => (
              <button
                key={rating}
                className="w-8 h-8 bg-amber-600 hover:bg-amber-700 text-black font-bold rounded border border-amber-500 transition-colors"
              >
                {rating}
              </button>
            ))}
          </div>
          <p className="text-amber-300 text-xs">
            Votez pour la qualité du forum
          </p>
        </CardContent>
      </Card>
    </div>
  );
};

export default MembersSection;
