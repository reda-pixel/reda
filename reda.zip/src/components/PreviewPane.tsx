import { useEffect, useRef, useState } from "react";
import {
  RefreshCw,
  Maximize,
  Minimize,
  Monitor,
  Smartphone,
  Tablet,
} from "lucide-react";
import { Button } from "@/components/ui/button";

interface PreviewPaneProps {
  htmlCode: string;
  cssCode: string;
  jsCode: string;
}

const PreviewPane = ({ htmlCode, cssCode, jsCode }: PreviewPaneProps) => {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [deviceMode, setDeviceMode] = useState<"desktop" | "tablet" | "mobile">(
    "desktop",
  );
  const [isRefreshing, setIsRefreshing] = useState(false);

  const updatePreview = () => {
    if (!iframeRef.current) return;

    const iframe = iframeRef.current;
    const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;

    if (!iframeDoc) return;

    const html = `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Preview</title>
        <style>
          body { margin: 0; padding: 0; }
          ${cssCode}
        </style>
      </head>
      <body>
        ${htmlCode}
        <script>
          try {
            ${jsCode}
          } catch (error) {
            console.error('JavaScript Error:', error);
            document.body.innerHTML += '<div style="background: #ff6b6b; color: white; padding: 10px; margin: 10px; border-radius: 5px;"><strong>JavaScript Error:</strong> ' + error.message + '</div>';
          }
        </script>
      </body>
      </html>
    `;

    iframeDoc.open();
    iframeDoc.write(html);
    iframeDoc.close();
  };

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      updatePreview();
    }, 500);

    return () => clearTimeout(timeoutId);
  }, [htmlCode, cssCode, jsCode]);

  const refreshPreview = () => {
    setIsRefreshing(true);
    updatePreview();
    setTimeout(() => setIsRefreshing(false), 500);
  };

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  const getDeviceWidth = () => {
    switch (deviceMode) {
      case "mobile":
        return "375px";
      case "tablet":
        return "768px";
      case "desktop":
      default:
        return "100%";
    }
  };

  const getDeviceHeight = () => {
    switch (deviceMode) {
      case "mobile":
        return "667px";
      case "tablet":
        return "1024px";
      case "desktop":
      default:
        return "100%";
    }
  };

  return (
    <div
      className={`flex flex-col h-full ${isFullscreen ? "fixed inset-0 z-50 bg-gray-900" : ""}`}
    >
      {/* Header */}
      <div className="bg-gray-800 border-b border-gray-700 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <h3 className="text-white font-medium">معاينة مباشرة</h3>
          <div className="flex items-center space-x-2">
            <Button
              onClick={() => setDeviceMode("desktop")}
              variant={deviceMode === "desktop" ? "default" : "outline"}
              size="sm"
              className="border-gray-600"
            >
              <Monitor className="h-4 w-4" />
            </Button>
            <Button
              onClick={() => setDeviceMode("tablet")}
              variant={deviceMode === "tablet" ? "default" : "outline"}
              size="sm"
              className="border-gray-600"
            >
              <Tablet className="h-4 w-4" />
            </Button>
            <Button
              onClick={() => setDeviceMode("mobile")}
              variant={deviceMode === "mobile" ? "default" : "outline"}
              size="sm"
              className="border-gray-600"
            >
              <Smartphone className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <Button
            onClick={refreshPreview}
            variant="outline"
            size="sm"
            className="border-gray-600 text-gray-300"
            disabled={isRefreshing}
          >
            <RefreshCw
              className={`h-4 w-4 ${isRefreshing ? "animate-spin" : ""}`}
            />
          </Button>
          <Button
            onClick={toggleFullscreen}
            variant="outline"
            size="sm"
            className="border-gray-600 text-gray-300"
          >
            {isFullscreen ? (
              <Minimize className="h-4 w-4" />
            ) : (
              <Maximize className="h-4 w-4" />
            )}
          </Button>
        </div>
      </div>

      {/* Preview Area */}
      <div className="flex-1 bg-gray-100 flex items-center justify-center overflow-auto">
        <div
          className="bg-white shadow-lg transition-all duration-300"
          style={{
            width: getDeviceWidth(),
            height: deviceMode === "desktop" ? "100%" : getDeviceHeight(),
            maxWidth: "100%",
            maxHeight: "100%",
          }}
        >
          <iframe
            ref={iframeRef}
            className="w-full h-full border-none"
            title="Code Preview"
            sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-modals"
          />
        </div>
      </div>

      {/* Status Bar */}
      <div className="bg-gray-800 border-t border-gray-700 px-4 py-2 text-xs text-gray-400 flex justify-between">
        <div className="flex items-center space-x-4">
          <span>
            الوضع:{" "}
            {deviceMode === "desktop"
              ? "سطح المكتب"
              : deviceMode === "tablet"
                ? "تابلت"
                : "موبايل"}
          </span>
          <span>العرض: {getDeviceWidth()}</span>
          {deviceMode !== "desktop" && (
            <span>الارتفاع: {getDeviceHeight()}</span>
          )}
        </div>
        <div>معاينة مباشرة</div>
      </div>
    </div>
  );
};

export default PreviewPane;
