import { motion } from "framer-motion";
import { Play, Heart, MoreHorizontal, Clock } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface MediaCardProps {
  title: string;
  artist?: string;
  duration?: string;
  thumbnail?: string;
  type: "video" | "audio" | "image";
  isLiked?: boolean;
}

const MediaCard = ({
  title,
  artist,
  duration,
  thumbnail,
  type,
  isLiked = false,
}: MediaCardProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3 }}
      whileHover={{ scale: 1.02 }}
    >
      <Card className="bg-gray-900/50 border-gray-800 backdrop-blur-sm hover:border-gray-700 transition-all duration-300 group overflow-hidden">
        <CardContent className="p-0">
          {/* Thumbnail */}
          <div className="relative aspect-video bg-gradient-to-br from-purple-500/20 to-pink-500/20 flex items-center justify-center">
            {thumbnail ? (
              <img
                src={thumbnail}
                alt={title}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-16 h-16 bg-gray-800 rounded-full flex items-center justify-center">
                <Play className="h-8 w-8 text-gray-400" />
              </div>
            )}

            {/* Overlay */}
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-all duration-300 flex items-center justify-center opacity-0 group-hover:opacity-100">
              <Button
                size="sm"
                className="bg-white/20 hover:bg-white/30 backdrop-blur-sm text-white border-none"
              >
                <Play className="h-4 w-4 mr-2" />
                Play
              </Button>
            </div>

            {/* Duration badge */}
            {duration && (
              <div className="absolute bottom-2 right-2 bg-black/60 backdrop-blur-sm text-white text-xs px-2 py-1 rounded">
                {duration}
              </div>
            )}
          </div>

          {/* Content */}
          <div className="p-4">
            <div className="flex items-start justify-between">
              <div className="flex-1 min-w-0">
                <h3 className="text-white font-medium text-sm mb-1 truncate">
                  {title}
                </h3>
                {artist && (
                  <p className="text-gray-400 text-xs truncate">{artist}</p>
                )}
                <div className="flex items-center mt-2 text-xs text-gray-500">
                  <Clock className="h-3 w-3 mr-1" />
                  <span>2 hours ago</span>
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center space-x-1 ml-2">
                <Button
                  variant="ghost"
                  size="sm"
                  className={`h-8 w-8 p-0 ${
                    isLiked ? "text-red-400" : "text-gray-400"
                  } hover:text-red-400`}
                >
                  <Heart
                    className="h-4 w-4"
                    fill={isLiked ? "currentColor" : "none"}
                  />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0 text-gray-400 hover:text-white"
                >
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default MediaCard;
