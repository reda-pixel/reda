import { motion } from "framer-motion";
import {
  Users,
  Play,
  Download,
  Heart,
  TrendingUp,
  Activity,
  Calendar,
  Search,
  Filter,
  Grid,
  List,
} from "lucide-react";
import StatsWidget from "./StatsWidget";
import MediaCard from "./MediaCard";
import MediaPlayer from "./MediaPlayer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const Dashboard = () => {
  const stats = [
    {
      title: "Total Users",
      value: "12,458",
      change: "12%",
      changeType: "increase" as const,
      icon: Users,
      color: "purple" as const,
    },
    {
      title: "Total Views",
      value: "89,234",
      change: "8%",
      changeType: "increase" as const,
      icon: Play,
      color: "blue" as const,
    },
    {
      title: "Downloads",
      value: "3,421",
      change: "15%",
      changeType: "increase" as const,
      icon: Download,
      color: "green" as const,
    },
    {
      title: "Favorites",
      value: "1,890",
      change: "3%",
      changeType: "decrease" as const,
      icon: Heart,
      color: "pink" as const,
    },
  ];

  const mediaItems = [
    {
      title: "Epic Gaming Highlights",
      artist: "GameStudio",
      duration: "15:32",
      type: "video" as const,
      isLiked: true,
    },
    {
      title: "Chill Lo-Fi Beats",
      artist: "MusicProducer",
      duration: "3:45",
      type: "audio" as const,
      isLiked: false,
    },
    {
      title: "Design Tutorial",
      artist: "CreativeDesigner",
      duration: "22:18",
      type: "video" as const,
      isLiked: true,
    },
    {
      title: "Podcast Episode #12",
      artist: "TechTalks",
      duration: "45:20",
      type: "audio" as const,
      isLiked: false,
    },
    {
      title: "Photography Tips",
      artist: "PhotoPro",
      duration: "18:45",
      type: "video" as const,
      isLiked: true,
    },
    {
      title: "Ambient Sounds",
      artist: "NatureSounds",
      duration: "60:00",
      type: "audio" as const,
      isLiked: false,
    },
  ];

  const recentActivity = [
    { action: "New user registered", time: "2 minutes ago", type: "user" },
    { action: "Video uploaded", time: "5 minutes ago", type: "content" },
    { action: "Comment posted", time: "8 minutes ago", type: "interaction" },
    { action: "File downloaded", time: "12 minutes ago", type: "download" },
    {
      action: "User liked content",
      time: "15 minutes ago",
      type: "interaction",
    },
  ];

  return (
    <div className="p-6 space-y-6 pb-32">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Dashboard</h1>
          <p className="text-gray-400">
            Welcome back! Here's what's happening.
          </p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search..."
              className="pl-10 bg-gray-900/50 border-gray-800 text-white w-64"
            />
          </div>
          <Button variant="outline" className="border-gray-800 text-gray-400">
            <Filter className="h-4 w-4 mr-2" />
            Filter
          </Button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <StatsWidget key={index} {...stat} />
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Media Content */}
        <div className="lg:col-span-2">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-white">Recent Content</h2>
            <div className="flex items-center space-x-2">
              <Button
                variant="ghost"
                size="sm"
                className="text-gray-400 hover:text-white"
              >
                <Grid className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="text-gray-400 hover:text-white"
              >
                <List className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {mediaItems.map((item, index) => (
              <MediaCard key={index} {...item} />
            ))}
          </div>
        </div>

        {/* Sidebar Content */}
        <div className="space-y-6">
          {/* Activity Feed */}
          <Card className="bg-gray-900/50 border-gray-800 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Activity className="h-5 w-5 mr-2 text-purple-400" />
                Recent Activity
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {recentActivity.map((activity, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-start space-x-3 p-3 rounded-lg bg-gray-800/30"
                >
                  <div className="w-2 h-2 bg-purple-400 rounded-full mt-2 flex-shrink-0"></div>
                  <div className="flex-1">
                    <p className="text-sm text-white">{activity.action}</p>
                    <p className="text-xs text-gray-400">{activity.time}</p>
                  </div>
                </motion.div>
              ))}
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <Card className="bg-gray-900/50 border-gray-800 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <TrendingUp className="h-5 w-5 mr-2 text-green-400" />
                Performance
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">Engagement Rate</span>
                  <span className="text-sm font-medium text-white">78.5%</span>
                </div>
                <div className="w-full bg-gray-800 rounded-full h-2">
                  <div className="bg-gradient-to-r from-purple-500 to-pink-500 h-2 rounded-full w-3/4"></div>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">Completion Rate</span>
                  <span className="text-sm font-medium text-white">92.1%</span>
                </div>
                <div className="w-full bg-gray-800 rounded-full h-2">
                  <div className="bg-gradient-to-r from-blue-500 to-cyan-500 h-2 rounded-full w-[92%]"></div>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">
                    User Satisfaction
                  </span>
                  <span className="text-sm font-medium text-white">96.3%</span>
                </div>
                <div className="w-full bg-gray-800 rounded-full h-2">
                  <div className="bg-gradient-to-r from-green-500 to-emerald-500 h-2 rounded-full w-[96%]"></div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Calendar Widget */}
          <Card className="bg-gray-900/50 border-gray-800 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Calendar className="h-5 w-5 mr-2 text-blue-400" />
                Upcoming Events
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center space-x-3 p-2 rounded bg-gray-800/30">
                  <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                  <div>
                    <p className="text-sm text-white">Team Meeting</p>
                    <p className="text-xs text-gray-400">Today, 2:00 PM</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3 p-2 rounded bg-gray-800/30">
                  <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
                  <div>
                    <p className="text-sm text-white">Content Review</p>
                    <p className="text-xs text-gray-400">Tomorrow, 10:00 AM</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3 p-2 rounded bg-gray-800/30">
                  <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                  <div>
                    <p className="text-sm text-white">Product Launch</p>
                    <p className="text-xs text-gray-400">Friday, 3:00 PM</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Media Player Bar */}
      <div className="fixed bottom-0 left-72 right-0 p-4 bg-gray-950/95 backdrop-blur-lg border-t border-gray-800/50">
        <MediaPlayer />
      </div>
    </div>
  );
};

export default Dashboard;
