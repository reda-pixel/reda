import { motion } from "framer-motion";
import { Code, Palette, Zap, Users } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const About = () => {
  const skills = [
    {
      icon: <Code className="h-8 w-8" />,
      title: "Frontend Development",
      description: "React, TypeScript, Next.js, TailwindCSS",
      color: "text-neon-pink",
    },
    {
      icon: <Palette className="h-8 w-8" />,
      title: "UI/UX Design",
      description: "Figma, Adobe Creative Suite, Prototyping",
      color: "text-neon-blue",
    },
    {
      icon: <Zap className="h-8 w-8" />,
      title: "Performance",
      description: "Optimization, SEO, Core Web Vitals",
      color: "text-neon-purple",
    },
    {
      icon: <Users className="h-8 w-8" />,
      title: "Collaboration",
      description: "Team leadership, Agile, Code review",
      color: "text-neon-pink",
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
      },
    },
  };

  return (
    <section id="about" className="py-20 bg-dark-surface/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="gradient-text">About Me</span>
          </h2>
          <div className="w-20 h-1 bg-gradient-to-r from-neon-pink to-neon-blue mx-auto mb-8"></div>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
            Welcome to my digital realm. I'm a passionate creator who believes
            in the power of clean code, beautiful design, and meaningful user
            experiences. With years of experience crafting digital solutions, I
            bring ideas to life through innovative technology and creative
            problem-solving.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <div className="relative">
              <div className="w-full h-96 bg-gradient-to-br from-neon-pink/20 to-neon-blue/20 rounded-2xl glass-effect p-8 flex items-center justify-center">
                <div className="text-center">
                  <div className="w-32 h-32 bg-gradient-to-br from-neon-pink to-neon-blue rounded-full mx-auto mb-6 flex items-center justify-center">
                    <span className="text-4xl font-bold text-white">JS</span>
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-2">
                    5+ Years
                  </h3>
                  <p className="text-gray-300">of Experience</p>
                </div>
              </div>

              {/* Floating elements */}
              <motion.div
                className="absolute -top-4 -right-4 w-20 h-20 bg-neon-pink/20 rounded-full glass-effect flex items-center justify-center"
                animate={{
                  y: [0, -10, 0],
                  rotate: [0, 180, 360],
                }}
                transition={{
                  duration: 4,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
              >
                <Code className="h-8 w-8 text-neon-pink" />
              </motion.div>

              <motion.div
                className="absolute -bottom-4 -left-4 w-16 h-16 bg-neon-blue/20 rounded-full glass-effect flex items-center justify-center"
                animate={{
                  y: [0, 10, 0],
                  rotate: [360, 180, 0],
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
              >
                <Palette className="h-6 w-6 text-neon-blue" />
              </motion.div>
            </div>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="space-y-6"
          >
            {skills.map((skill, index) => (
              <motion.div key={index} variants={itemVariants}>
                <Card className="glass-effect border-dark-border hover:border-neon-pink/50 transition-all duration-300 group">
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <div
                        className={`${skill.color} group-hover:neon-glow transition-all duration-300`}
                      >
                        {skill.icon}
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-white mb-2">
                          {skill.title}
                        </h3>
                        <p className="text-gray-400">{skill.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
          className="mt-16 text-center"
        >
          <div className="glass-effect rounded-2xl p-8 border border-dark-border">
            <h3 className="text-2xl font-bold text-white mb-4">
              Let's Create Something Amazing
            </h3>
            <p className="text-gray-300 text-lg">
              I'm always excited to take on new challenges and collaborate with
              creative minds. Ready to bring your vision to life with
              cutting-edge technology and stunning design.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default About;
