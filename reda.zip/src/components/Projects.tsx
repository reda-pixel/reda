import { motion } from "framer-motion";
import { ExternalLink, Github, Eye } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const Projects = () => {
  const projects = [
    {
      title: "E-Commerce Platform",
      description:
        "A modern e-commerce solution built with React, Next.js, and Stripe. Features include real-time inventory, advanced filtering, and seamless checkout experience.",
      image: "/placeholder.svg",
      technologies: ["React", "Next.js", "TypeScript", "Stripe", "MongoDB"],
      github: "https://github.com",
      live: "https://example.com",
      category: "Web App",
    },
    {
      title: "AI Dashboard",
      description:
        "An intelligent analytics dashboard powered by machine learning. Real-time data visualization, predictive analytics, and automated insights.",
      image: "/placeholder.svg",
      technologies: ["React", "D3.js", "Python", "TensorFlow", "PostgreSQL"],
      github: "https://github.com",
      live: "https://example.com",
      category: "AI/ML",
    },
    {
      title: "Mobile Finance App",
      description:
        "A comprehensive personal finance management app with budget tracking, expense categorization, and investment portfolio management.",
      image: "/placeholder.svg",
      technologies: ["React Native", "Node.js", "Firebase", "Plaid API"],
      github: "https://github.com",
      live: "https://example.com",
      category: "Mobile",
    },
    {
      title: "Creative Portfolio",
      description:
        "An interactive portfolio website for a digital artist featuring 3D animations, smooth transitions, and immersive user experience.",
      image: "/placeholder.svg",
      technologies: ["React", "Three.js", "Framer Motion", "GSAP"],
      github: "https://github.com",
      live: "https://example.com",
      category: "Portfolio",
    },
    {
      title: "Real-time Chat Platform",
      description:
        "A scalable messaging platform with real-time communication, file sharing, video calls, and team collaboration features.",
      image: "/placeholder.svg",
      technologies: ["React", "Socket.io", "Node.js", "Redis", "WebRTC"],
      github: "https://github.com",
      live: "https://example.com",
      category: "Communication",
    },
    {
      title: "Blockchain Voting System",
      description:
        "A secure and transparent voting system built on blockchain technology ensuring immutable records and voter privacy.",
      image: "/placeholder.svg",
      technologies: ["React", "Solidity", "Web3.js", "Ethereum", "IPFS"],
      github: "https://github.com",
      live: "https://example.com",
      category: "Blockchain",
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
      },
    },
  };

  return (
    <section id="projects" className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="gradient-text">Featured Projects</span>
          </h2>
          <div className="w-20 h-1 bg-gradient-to-r from-neon-pink to-neon-blue mx-auto mb-8"></div>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            A showcase of my latest work spanning web applications, mobile apps,
            and innovative digital solutions. Each project represents a unique
            challenge and creative solution.
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {projects.map((project, index) => (
            <motion.div key={index} variants={itemVariants}>
              <Card className="glass-effect border-dark-border hover:border-neon-pink/50 transition-all duration-300 group h-full overflow-hidden">
                <div className="relative">
                  <div className="h-48 bg-gradient-to-br from-neon-pink/20 to-neon-blue/20 flex items-center justify-center">
                    <Eye className="h-12 w-12 text-white/50" />
                  </div>
                  <div className="absolute top-4 right-4">
                    <span className="bg-neon-pink/20 text-neon-pink px-3 py-1 rounded-full text-sm font-medium glass-effect">
                      {project.category}
                    </span>
                  </div>
                </div>

                <CardContent className="p-6">
                  <h3 className="text-xl font-bold text-white mb-3 group-hover:text-neon-pink transition-colors duration-300">
                    {project.title}
                  </h3>
                  <p className="text-gray-400 mb-4 text-sm leading-relaxed">
                    {project.description}
                  </p>

                  <div className="flex flex-wrap gap-2 mb-6">
                    {project.technologies.map((tech, techIndex) => (
                      <span
                        key={techIndex}
                        className="bg-dark-surface/50 text-gray-300 px-2 py-1 rounded text-xs border border-dark-border"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>

                  <div className="flex space-x-3">
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-neon-pink/50 text-neon-pink hover:border-neon-pink hover:neon-glow flex-1"
                      asChild
                    >
                      <a
                        href={project.github}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <Github className="h-4 w-4 mr-2" />
                        Code
                      </a>
                    </Button>
                    <Button
                      size="sm"
                      className="bg-gradient-to-r from-neon-pink to-neon-blue hover:opacity-90 flex-1"
                      asChild
                    >
                      <a
                        href={project.live}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <ExternalLink className="h-4 w-4 mr-2" />
                        Live
                      </a>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <Button
            size="lg"
            variant="outline"
            className="border-neon-pink/50 text-neon-pink hover:border-neon-pink hover:neon-glow"
            asChild
          >
            <a
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
            >
              View All Projects on GitHub
            </a>
          </Button>
        </motion.div>
      </div>
    </section>
  );
};

export default Projects;
