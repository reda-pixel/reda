import { motion } from "framer-motion";
import { Calendar, Users, MessageSquare, Eye } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const MomentsSection = () => {
  const welcomeData = {
    user: {
      name: "WELCOME TO JASPER",
      avatar: "/placeholder.svg",
      status: "online",
    },
    season: "AUTUMN 2019",
    tabs: ["TOPICS", "SEASONAL", "VISITORS"],
  };

  const sidebarItems = [
    { title: "THE FITZROY", count: "5", image: "/placeholder.svg" },
    { title: "ANOTHER ITEM", count: "12", image: "/placeholder.svg" },
    { title: "SAMPLE ITEM", count: "8", image: "/placeholder.svg" },
    { title: "MORE CONTENT", count: "3", image: "/placeholder.svg" },
  ];

  return (
    <div className="grid lg:grid-cols-4 gap-6">
      {/* Main Welcome Card */}
      <div className="lg:col-span-3">
        <Card className="bg-gray-800/60 border-gray-700 backdrop-blur-sm">
          <CardContent className="p-8">
            <div className="grid md:grid-cols-3 gap-8 items-start">
              {/* User Info */}
              <div className="text-center">
                <div className="w-24 h-24 bg-gray-700 rounded-lg mx-auto mb-4 flex items-center justify-center">
                  <div className="w-20 h-20 bg-gray-600 rounded"></div>
                </div>
                <h3 className="text-gray-200 font-medium text-lg">
                  {welcomeData.user.name}
                </h3>
              </div>

              {/* Season Info */}
              <div className="text-center">
                <div className="mb-6">
                  <h2 className="text-2xl font-light text-gray-300 mb-2">
                    {welcomeData.season}
                  </h2>
                  <div className="w-full h-1 bg-gray-700 rounded-full mb-4">
                    <div className="w-3/4 h-1 bg-gray-500 rounded-full"></div>
                  </div>
                </div>

                {/* Navigation Tabs */}
                <div className="grid grid-cols-3 gap-2">
                  {welcomeData.tabs.map((tab, index) => (
                    <button
                      key={index}
                      className="bg-gray-700 hover:bg-gray-600 text-gray-300 text-sm py-2 px-3 rounded transition-colors"
                    >
                      {tab}
                    </button>
                  ))}
                </div>
              </div>

              {/* Description */}
              <div className="text-gray-400 text-sm leading-relaxed">
                <p>
                  jasper is a small town heavily nestled and isolated by the
                  solemn cascade mountains. it's population
                </p>
                <br />
                <p>
                  capture the notion death was ever present but never unwelcome.
                  as if death brings new life, you are right at home.
                </p>
                <br />
                <p>jasper beckons new souls and returns old ones</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Sidebar */}
      <div className="space-y-4">
        {sidebarItems.map((item, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="bg-gray-800/60 border-gray-700 hover:border-gray-600 transition-colors">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-gray-700 rounded flex-shrink-0"></div>
                  <div className="flex-1">
                    <h4 className="text-gray-200 text-sm font-medium">
                      {item.title}
                    </h4>
                    <p className="text-gray-500 text-xs">{item.count} items</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default MomentsSection;
