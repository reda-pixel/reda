import {
  Download,
  Play,
  RotateCcw,
  Share,
  Save,
  Grid,
  Columns,
  Copy,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "@/hooks/use-toast";

interface ToolbarProps {
  htmlCode: string;
  cssCode: string;
  jsCode: string;
  layout: "horizontal" | "vertical";
  setLayout: (layout: "horizontal" | "vertical") => void;
}

const Toolbar = ({
  htmlCode,
  cssCode,
  jsCode,
  layout,
  setLayout,
}: ToolbarProps) => {
  const downloadCode = () => {
    const fullHtml = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Code</title>
    <style>
${cssCode}
    </style>
</head>
<body>
${htmlCode}
    <script>
${jsCode}
    </script>
</body>
</html>`;

    const blob = new Blob([fullHtml], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "my-code.html";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast({
      title: "تم التحميل!",
      description: "تم تحميل الملف بنجاح",
    });
  };

  const saveProject = () => {
    const project = {
      html: htmlCode,
      css: cssCode,
      js: jsCode,
      timestamp: new Date().toISOString(),
    };

    localStorage.setItem("codeEditor_project", JSON.stringify(project));
    toast({
      title: "تم الحفظ!",
      description: "تم حفظ المشروع في التخزين المحلي",
    });
  };

  const shareProject = async () => {
    try {
      const shareData = {
        title: "My Code Project",
        text: "Check out my code!",
        url: window.location.href,
      };

      // Check if navigator.share is available and supported
      if (
        navigator.share &&
        navigator.canShare &&
        navigator.canShare(shareData)
      ) {
        await navigator.share(shareData);
        toast({
          title: "تم المشاركة!",
          description: "تم مشاركة المشروع بنجاح",
        });
      } else {
        // Fallback: use legacy clipboard method or create a temporary input
        await copyToClipboardFallback(window.location.href);
        toast({
          title: "تم نسخ الرابط!",
          description: "تم نسخ رابط المشروع إلى الحافظة",
        });
      }
    } catch (error) {
      console.error("Error sharing:", error);
      // Final fallback: copy to clipboard using legacy method
      try {
        await copyToClipboardFallback(window.location.href);
        toast({
          title: "تم نسخ الرابط!",
          description: "تم نسخ رابط المشروع إلى الحافظة (وضع متوافق)",
        });
      } catch (fallbackError) {
        toast({
          title: "خطأ في المشاركة",
          description: "لا يمكن مشاركة المشروع في الوقت الحالي",
          variant: "destructive",
        });
      }
    }
  };

  const copyCode = async () => {
    const fullCode = `HTML:\n${htmlCode}\n\nCSS:\n${cssCode}\n\nJavaScript:\n${jsCode}`;
    try {
      // Try modern clipboard API first
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(fullCode);
        toast({
          title: "تم النسخ!",
          description: "تم نسخ الكود إلى الحافظة",
        });
      } else {
        // Fallback for browsers without clipboard API support
        await copyToClipboardFallback(fullCode);
        toast({
          title: "تم النسخ!",
          description: "تم نسخ الكود إلى الحافظة (وضع متوافق)",
        });
      }
    } catch (error) {
      console.error("Error copying:", error);
      // Try fallback method
      try {
        await copyToClipboardFallback(fullCode);
        toast({
          title: "تم النسخ!",
          description: "تم نسخ الكود إلى الحافظة (وضع متوافق)",
        });
      } catch (fallbackError) {
        toast({
          title: "خطأ في النسخ",
          description: "لا يمكن نسخ الكود في الوقت الحالي",
          variant: "destructive",
        });
      }
    }
  };

  // Fallback function for clipboard operations
  const copyToClipboardFallback = (text: string): Promise<void> => {
    return new Promise((resolve, reject) => {
      try {
        // Create a temporary textarea element
        const textArea = document.createElement("textarea");
        textArea.value = text;
        textArea.style.position = "fixed";
        textArea.style.left = "-999999px";
        textArea.style.top = "-999999px";
        document.body.appendChild(textArea);

        // Select and copy the text
        textArea.focus();
        textArea.select();

        const successful = document.execCommand("copy");
        document.body.removeChild(textArea);

        if (successful) {
          resolve();
        } else {
          reject(new Error("Copy command failed"));
        }
      } catch (error) {
        reject(error);
      }
    });
  };

  const resetCode = () => {
    if (confirm("هل أنت متأكد من أنك تريد إعادة تعيين الكود؟")) {
      window.location.reload();
    }
  };

  return (
    <div className="bg-gray-800 border-b border-gray-700 px-4 py-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button
            onClick={downloadCode}
            className="bg-blue-600 hover:bg-blue-700 text-white flex items-center space-x-2"
          >
            <Download className="h-4 w-4" />
            <span>تحميل</span>
          </Button>

          <Button
            onClick={saveProject}
            variant="outline"
            className="border-gray-600 text-gray-300 hover:text-white flex items-center space-x-2"
          >
            <Save className="h-4 w-4" />
            <span>حفظ</span>
          </Button>

          <Button
            onClick={shareProject}
            variant="outline"
            className="border-gray-600 text-gray-300 hover:text-white flex items-center space-x-2"
          >
            <Share className="h-4 w-4" />
            <span>مشاركة</span>
          </Button>

          <Button
            onClick={copyCode}
            variant="outline"
            className="border-gray-600 text-gray-300 hover:text-white flex items-center space-x-2"
          >
            <Copy className="h-4 w-4" />
            <span>نسخ</span>
          </Button>
        </div>

        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <Button
              onClick={() => setLayout("horizontal")}
              variant={layout === "horizontal" ? "default" : "outline"}
              size="sm"
              className="border-gray-600"
            >
              <Columns className="h-4 w-4" />
            </Button>
            <Button
              onClick={() => setLayout("vertical")}
              variant={layout === "vertical" ? "default" : "outline"}
              size="sm"
              className="border-gray-600"
            >
              <Grid className="h-4 w-4" />
            </Button>
          </div>

          <Button
            onClick={resetCode}
            variant="outline"
            className="border-gray-600 text-gray-300 hover:text-white flex items-center space-x-2"
          >
            <RotateCcw className="h-4 w-4" />
            <span>إعادة تعيين</span>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Toolbar;
