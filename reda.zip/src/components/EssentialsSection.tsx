import { motion } from "framer-motion";
import { Info, Users, MessageSquare, Eye } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const EssentialsSection = () => {
  const essentialInfo = {
    title: "INFORMATION",
    description: "HOVER OVER TO FIND INFORMATION LINKS",
    stats: {
      posts: "8 POSTS",
      topics: "2 TOPICS",
      lastPost: "LAST POST BY",
      user: "AZEMORE",
    },
    content:
      "There is nothing you need to buy, there's nothing you need to be, there's no way to rush it, and here's a big suggestion: try: Try anything. Try this: Be",
  };

  return (
    <Card className="bg-gray-800/60 border-gray-700 backdrop-blur-sm">
      <CardHeader className="pb-0">
        <div className="flex items-center justify-between">
          <CardTitle className="text-2xl font-light text-gray-200 tracking-wide">
            essentials
          </CardTitle>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="grid md:grid-cols-4 gap-6">
          {/* Image placeholder */}
          <div className="md:col-span-1">
            <div className="w-full h-32 bg-gray-700 rounded-lg flex items-center justify-center">
              <div className="w-20 h-20 bg-gray-600 rounded"></div>
            </div>
          </div>

          {/* Content */}
          <div className="md:col-span-3">
            <div className="mb-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-lg font-medium text-gray-200 bg-gray-700 px-4 py-2 rounded">
                  {essentialInfo.title}
                </h3>
                <div className="text-right text-sm text-gray-400">
                  <div>{essentialInfo.stats.posts}</div>
                  <div>{essentialInfo.stats.topics}</div>
                </div>
              </div>

              <p className="text-sm text-gray-500 mb-4">
                {essentialInfo.description}
              </p>

              <p className="text-gray-400 text-sm leading-relaxed mb-4">
                {essentialInfo.content}
              </p>

              <div className="flex items-center justify-between text-xs text-gray-500">
                <div className="flex items-center space-x-4">
                  <span className="flex items-center">
                    <MessageSquare className="h-3 w-3 mr-1" />
                    {essentialInfo.stats.posts}
                  </span>
                  <span className="flex items-center">
                    <Users className="h-3 w-3 mr-1" />
                    {essentialInfo.stats.topics}
                  </span>
                </div>
                <div>
                  {essentialInfo.stats.lastPost} {essentialInfo.stats.user}
                </div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default EssentialsSection;
