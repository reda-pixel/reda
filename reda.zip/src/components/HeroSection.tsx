import { motion } from "framer-motion";

const HeroSection = () => {
  return (
    <section className="relative py-12 px-4 bg-gray-800/50">
      <div className="max-w-6xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h1 className="text-5xl md:text-7xl font-light text-gray-200 mb-4 tracking-wide">
            Moments
          </h1>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto leading-relaxed">
            HEY THERE! FEEL FREE TO VISIT OUR GUEST FRIENDLY DISCORD IN THE
            BOTTOM RIGHT CORNER
          </p>
        </motion.div>
      </div>
    </section>
  );
};

export default HeroSection;
