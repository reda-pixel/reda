import { motion } from "framer-motion";
import { Users, MessageSquare, Eye, Clock, TrendingUp } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const BoardSection = () => {
  const boardData = {
    title: "board information",
    onlineNow: {
      count: 41,
      users: [
        { name: "User1", avatar: "/placeholder.svg" },
        { name: "User2", avatar: "/placeholder.svg" },
        { name: "User3", avatar: "/placeholder.svg" },
        { name: "User4", avatar: "/placeholder.svg" },
      ],
    },
    recentTopics: {
      count: 494,
      topics: [
        {
          title: "SAMPLE TOPIC TITLE HERE",
          author: "Username",
          time: "2 hours ago",
          replies: 5,
        },
        {
          title: "ANOTHER INTERESTING DISCUSSION",
          author: "Member",
          time: "4 hours ago",
          replies: 12,
        },
        {
          title: "WEEKLY CHALLENGE THREAD",
          author: "Admin",
          time: "1 day ago",
          replies: 28,
        },
        {
          title: "NEW MEMBER INTRODUCTIONS",
          author: "Moderator",
          time: "2 days ago",
          replies: 15,
        },
      ],
    },
    stats: {
      totalMembers: 1247,
      totalPosts: 15842,
      onlineMembers: 41,
      guestUsers: 156,
    },
  };

  return (
    <div className="space-y-6">
      {/* Board Information Header */}
      <Card className="bg-gray-800/60 border-gray-700 backdrop-blur-sm">
        <CardHeader className="pb-2">
          <CardTitle className="text-xl font-light text-gray-200 tracking-wide text-center">
            {boardData.title}
          </CardTitle>
        </CardHeader>
      </Card>

      {/* Online Now */}
      <Card className="bg-gray-800/60 border-gray-700 backdrop-blur-sm">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-medium text-gray-200 flex items-center">
              <Users className="h-5 w-5 mr-2 text-gray-400" />
              ONLINE NOW
            </CardTitle>
            <span className="text-2xl font-bold text-gray-300">
              {boardData.onlineNow.count}
            </span>
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="grid grid-cols-2 gap-2">
            {boardData.onlineNow.users.map((user, index) => (
              <div
                key={index}
                className="flex items-center space-x-2 p-2 bg-gray-750 rounded"
              >
                <div className="w-8 h-8 bg-gray-600 rounded-full flex-shrink-0"></div>
                <span className="text-xs text-gray-400 truncate">
                  {user.name}
                </span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recent Topics */}
      <Card className="bg-gray-800/60 border-gray-700 backdrop-blur-sm">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-medium text-gray-200 flex items-center">
              <MessageSquare className="h-5 w-5 mr-2 text-gray-400" />
              RECENT TOPICS
            </CardTitle>
            <span className="text-2xl font-bold text-gray-300">
              {boardData.recentTopics.count}
            </span>
          </div>
        </CardHeader>
        <CardContent className="pt-0 space-y-3">
          {boardData.recentTopics.topics.map((topic, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="p-3 bg-gray-750 rounded-lg hover:bg-gray-700 transition-colors"
            >
              <h4 className="text-sm font-medium text-gray-200 mb-1 line-clamp-2">
                {topic.title}
              </h4>
              <div className="flex items-center justify-between text-xs text-gray-500">
                <span>by {topic.author}</span>
                <div className="flex items-center space-x-2">
                  <span className="flex items-center">
                    <MessageSquare className="h-3 w-3 mr-1" />
                    {topic.replies}
                  </span>
                  <span className="flex items-center">
                    <Clock className="h-3 w-3 mr-1" />
                    {topic.time}
                  </span>
                </div>
              </div>
            </motion.div>
          ))}

          <div className="text-center pt-2">
            <button className="text-xs text-gray-500 hover:text-gray-400 transition-colors">
              View all topics →
            </button>
          </div>
        </CardContent>
      </Card>

      {/* Statistics */}
      <Card className="bg-gray-800/60 border-gray-700 backdrop-blur-sm">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-medium text-gray-200 flex items-center">
            <TrendingUp className="h-5 w-5 mr-2 text-gray-400" />
            STATISTICS
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="space-y-3">
            <div className="flex items-center justify-between p-2 bg-gray-750 rounded">
              <span className="text-sm text-gray-400">Total Members</span>
              <span className="text-sm font-medium text-gray-200">
                {boardData.stats.totalMembers.toLocaleString()}
              </span>
            </div>
            <div className="flex items-center justify-between p-2 bg-gray-750 rounded">
              <span className="text-sm text-gray-400">Total Posts</span>
              <span className="text-sm font-medium text-gray-200">
                {boardData.stats.totalPosts.toLocaleString()}
              </span>
            </div>
            <div className="flex items-center justify-between p-2 bg-gray-750 rounded">
              <span className="text-sm text-gray-400">Online Members</span>
              <span className="text-sm font-medium text-green-400">
                {boardData.stats.onlineMembers}
              </span>
            </div>
            <div className="flex items-center justify-between p-2 bg-gray-750 rounded">
              <span className="text-sm text-gray-400">Guest Users</span>
              <span className="text-sm font-medium text-gray-300">
                {boardData.stats.guestUsers}
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Footer note */}
      <div className="bg-gray-750 rounded-lg p-4 text-center">
        <p className="text-xs text-gray-500 leading-relaxed">
          Welcome to our community! Join the conversation and connect with
          members from around the world. Share your thoughts, ideas, and
          experiences in our friendly environment.
        </p>
      </div>
    </div>
  );
};

export default BoardSection;
