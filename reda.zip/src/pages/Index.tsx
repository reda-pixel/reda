import { useState } from "react";
import Navigation from "@/components/Navigation";
import CodeEditor from "@/components/CodeEditor";
import PreviewPane from "@/components/PreviewPane";
import Toolbar from "@/components/Toolbar";

const Index = () => {
  const [htmlCode, setHtmlCode] = useState(`<div class="container">
  <h1>Hello World!</h1>
  <p>Welcome to our code editor!</p>
  <button onclick="changeColor()">Click me!</button>
</div>`);

  const [cssCode, setCssCode] = useState(`.container {
  max-width: 600px;
  margin: 50px auto;
  padding: 20px;
  text-align: center;
  font-family: Arial, sans-serif;
}

h1 {
  color: #333;
  margin-bottom: 20px;
}

button {
  background: #007bff;
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: 5px;
  cursor: pointer;
  font-size: 16px;
}

button:hover {
  background: #0056b3;
}`);

  const [jsCode, setJsCode] = useState(`function changeColor() {
  const colors = ['#ff6b6b', '#4ecdc4', '#45b7d1', '#f9ca24', '#f0932b'];
  const randomColor = colors[Math.floor(Math.random() * colors.length)];
  document.querySelector('h1').style.color = randomColor;
}

// Add some interactivity
document.addEventListener('DOMContentLoaded', function() {
  console.log('Code editor loaded successfully!');
});`);

  const [activeTab, setActiveTab] = useState<"html" | "css" | "js">("html");
  const [layout, setLayout] = useState<"horizontal" | "vertical">("horizontal");

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <Navigation />
      <Toolbar
        htmlCode={htmlCode}
        cssCode={cssCode}
        jsCode={jsCode}
        layout={layout}
        setLayout={setLayout}
      />

      <div className="flex-1 overflow-hidden">
        {layout === "horizontal" ? (
          <div className="flex h-[calc(100vh-120px)]">
            {/* Code Editors */}
            <div className="flex-1 flex flex-col">
              <CodeEditor
                htmlCode={htmlCode}
                setHtmlCode={setHtmlCode}
                cssCode={cssCode}
                setCssCode={setCssCode}
                jsCode={jsCode}
                setJsCode={setJsCode}
                activeTab={activeTab}
                setActiveTab={setActiveTab}
              />
            </div>

            {/* Preview */}
            <div className="flex-1 border-l border-gray-700">
              <PreviewPane
                htmlCode={htmlCode}
                cssCode={cssCode}
                jsCode={jsCode}
              />
            </div>
          </div>
        ) : (
          <div className="flex flex-col h-[calc(100vh-120px)]">
            {/* Code Editors */}
            <div className="flex-1">
              <CodeEditor
                htmlCode={htmlCode}
                setHtmlCode={setHtmlCode}
                cssCode={cssCode}
                setCssCode={setCssCode}
                jsCode={jsCode}
                setJsCode={setJsCode}
                activeTab={activeTab}
                setActiveTab={setActiveTab}
              />
            </div>

            {/* Preview */}
            <div className="flex-1 border-t border-gray-700">
              <PreviewPane
                htmlCode={htmlCode}
                cssCode={cssCode}
                jsCode={jsCode}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Index;
